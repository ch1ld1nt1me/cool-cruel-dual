import csv
from math import ceil


def analyze(fname, machine):
    servers = {'Y': (92, 1), 'Z1': (8, 8), 'H': (40, 2)}
    ncores, ngpus = servers[machine]

    with open(fname, newline='', encoding='utf8') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        first = True

        nruns = 0
        times = []
        for row in reader:
            if first:
                first = False
                continue

            nruns += 1
            if row[-4] == "False":
                # print("Note: skipping failed attempt.")
                continue
            times.append(float(row[-2].strip()))
        avg_time = sum(times) / len(times)

        corehours, gpu_hours = ncores * avg_time / 3600, ngpus * avg_time / 3600
        print(
            f"{len(times)} / {nruns} "
            f"& \\({ceil(avg_time):6d}\\) "
            f"& \\({corehours:6.1f}\\) "
            f"& \\({gpu_hours:6.1f}\\) "
            f"& {machine} \\\\"
        )


def __main__():
    print("succ. & time (s) & core-hours & GPU-hours & server \\\\")
    analyze('binomial-q12-w11.csv', 'Y')
    analyze('binomial-q12-w12.csv', 'Y')
    analyze('binomial-q28-w20.csv', 'Z1')
    analyze('binomial-q28-w21.csv', 'Z1')

    analyze('ternary-q26-w11.csv', 'Y')
    analyze('ternary-q29-w9.csv', 'H')
    analyze('ternary-q29-w10.csv', 'H')


if __name__ == "__main__":
    __main__()
