#!/usr/bin/env bash
set -euo pipefail

# Usage: ./setup_env.sh <conda_env_name>
# If no env name is provided, the script uses lwe_attack as name.

# Determine environment name
if [ $# -ge 1 ]; then
  ENV_NAME="$1"
else
  ENV_NAME="lwe_attack"
fi

echo "Creating distributable environment '${ENV_NAME}' from environment.yml..."
conda env create -f environment.yml -n "${ENV_NAME}"

# Activate the new environment
echo "Activating environment '${ENV_NAME}'..."
eval "$(conda shell.bash hook)"
conda activate "${ENV_NAME}"

sudo apt-get install gcc libgmp-dev libmpfr-dev libqd-dev fplll-tools

# Install BLASter in editable mode
echo "Installing BLASter in editable mode..."
# pushd BLASter >/dev/null
# pip install -e .
# popd >/dev/null

cd ./BLASter/
make eigen3
pip install -e .
cp ./src/blaster_core.cpython-312-x86_64-linux-gnu.so ./src/blaster/
cd ../

# Build G6K-GPU-Tensor
echo "Building G6K-GPU-Tensor..."
# pushd G6K-GPU-Tensor >/dev/null
# ./rebuild.sh -f -y
# popd >/dev/null

cd ./G6K-GPU-Tensor
./rebuild.sh -f -y
pip install -e .
cd ../


# Install lattice-estimator
echo "Installing lattice-estimator in editable mode..."
pushd lattice-estimator >/dev/null
pip install -e .
popd >/dev/null

# cd ./lattice-estimator
# pip install -e .
# cd ../

pip install -r requirements.txt
conda install -c conda-forge multiprocessing-logging tqdm

echo "All done! Your environment is ready and repositories are cloned and installed."
