import csv
import sys


def analyze(fname):
    with open(fname, newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        first = True

        times = []
        for row in reader:
            if first:
                first = False
                continue
            times.append(float(row[-2].strip()) / 3600.0)

        print("Times (h): ", *[f"{x:.1f}," for x in times])

        avgT, minT, maxT = sum(times) / len(times), min(times), max(times)
        print(f"AVERAGE: {avgT:.3f}h")
        print(f"MIN:     {minT:.1f}h")
        print(f"MAX:     {maxT:.1f}h")


for fname in sys.argv[1:]:
    analyze(fname)
